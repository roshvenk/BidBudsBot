import random
import math


class CompetitorInstance():

    def __init__(self):
        # initialize personal variables
        self.phase1length = 3
        self.phase = 1
        self.index = None
        self.trueValue = None
        self.lastBidAmount = 1
        self.currentRound = 0
        self.roundWhenPassedMean = None
        # each item stores (round, bidDifference)
        self.bots = [[], [], [], [], [], [], [], [], [], []]

        self.suspectedTeamList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        self.suspectedTeamTrueValueList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        self.ownTeamList = []
        self.NonNPCTeamList = []
        self.KnownTrueValueList = []

        pass

    def onGameStart(self, engine, gameParameters):
        # engine: an instance of the game engine with functions as outlined in the documentation.
        self.engine = engine
        # gameParameters: A dictionary containing a variety of game parameters
        self.gameParameters = gameParameters

    def onAuctionStart(self, index, trueValue):
        # index is the current player's index, that usually stays put from game to game
        # trueValue is -1 if this bot doesn't know the true value

        self.index = index
        self.trueValue = trueValue

    def onBidMade(self, whoMadeBid, howMuch):
        # whoMadeBid is the index of the player that made the bid
        # howMuch is the amount that the bid was

        bidIncrement = howMuch - self.lastBidAmount

        if self.currentRound <= self.phase1length:
            hash1Result = self.hash1(self.bots, whoMadeBid)
            hash2Result = self.hash2(self.bots, whoMadeBid)

            if whoMadeBid in self.suspectedTeamList:
                if (hash1Result != bidIncrement):
                    if(hash2Result != bidIncrement):
                        self.suspectedTeamList.remove(whoMadeBid)

            if whoMadeBid in self.suspectedTeamTrueValueList:
                if(hash2Result != bidIncrement):
                    self.suspectedTeamTrueValueList.remove(whoMadeBid)

        self.bots[whoMadeBid].append((self.currentRound, bidIncrement))

        # If bid amount is greater than 24, we know its an NPC
        if bidIncrement > 24 and whoMadeBid not in self.NonNPCTeamList:
            self.NonNPCTeamList.append(whoMadeBid)

        self.lastBidAmount = howMuch

    def checkAndUpdateState(self):
        if self.phase == 1 and self.currentRound == (self.phase1length + 1):
            self.phase = 2

    def onMyTurn(self, lastBid):

        self.checkAndUpdateState()

        if self.phase == 1:
            if self.trueValue < 0:
                bidIncrement = self.hash1(self.bots, self.index)
            else:
                bidIncrement = self.hash2(self.bots, self.index)

            self.engine.makeBid(lastBid + bidIncrement)

        elif self.phase == 2:

            #if we know the true value, stop bidding once we are about to reach it 
            if self.trueValue >= 0:
                if self.lastBidAmount < (self.trueValue - 24):
                    self.engine.makeBid(lastBid + 8 + math.floor(random.random() * 16))
        
            #for bots who dont know the true value, check the history of the bot who knows the true value
            else:
                self.NPCBotCode()



        # at the end of phase 1: check if a bot didn't bid n times in the forst n rounds where n = to phase 1 length
        if self.currentRound == self.phase1length+1:
            self.engine.print("phase 1 end")
            for i in range(10):
                if len(self.bots[i]) < self.phase1length:
                    if(i in self.suspectedTeamList):
                        self.suspectedTeamList.remove(i)
                    if(i in self.suspectedTeamTrueValueList):
                        self.suspectedTeamTrueValueList.remove(i)

        self.currentRound += 1

    def onAuctionEnd(self):
        # Now is the time to report team members, or do any cleanup.

        # check bid history for

        self.engine.print("my index:" + str(self.index))

        # remove self.index before submitting
        self.suspectedTeamList.remove(self.index)
        if self.index in self.suspectedTeamTrueValueList:
            self.suspectedTeamTrueValueList.remove(self.index)

        self.engine.print(self.suspectedTeamList)
        self.engine.print(self.suspectedTeamTrueValueList)
        self.engine.reportTeams(self.suspectedTeamList,
                                self.suspectedTeamTrueValueList, self.NonNPCTeamList)

        pass

    def hash1(self, fullHistory, index):
        variability = 16

        diff = index
        for botHistory in fullHistory:
            for i in botHistory:
                diff += (i[1] + index)  # bid diff
                diff %= variability
        if(diff <= 0):
            diff = (index**index+index) % variability
        return (8 + diff)

    def hash2(self, fullHistory, index):
        variability = 16

        diff = index
        for botHistory in fullHistory:
            for i in botHistory:
                diff = abs(diff-(i[1]*(index+1)))  # bid diff
                diff %= variability

        if(diff <= 0):
            diff = (index**index + index) % variability
        return (8 + diff)

    def NPCBotCode(self):
        pr = 32/50
        if self.lastBidAmount > self.gameParameters["meanTrueValue"]/4:
            pr = 16/100
        if self.lastBidAmount > self.gameParameters["meanTrueValue"]*3/4:
            pr = 2/50
        if random.random() < pr:
            self.engine.makeBid(math.floor(
                self.lastBidAmount+(self.gameParameters["minimumBid"]*(1+2*random.random()))))

    # our bot bidding startedy in phase 2 did nothing just randomly
    def botbidstrategy(self):
        self.engine.makeBid(math.floor(
            self.lastBidAmount+(self.gameParameters["minimumBid"]*(1+2*random.random()))))
